package com.handstandtech.brandfinder.server.util;

public class ContentTypes {
	public static final String APPLICATION_JSON_UTF8 = "application/json; charset=utf-8";
}
